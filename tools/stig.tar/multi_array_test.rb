#!/opt/puppet/bin/ruby
#

infiles = %w( 
  accounts
  audio
  audit 
  banner
  boot
  core
  ipv6
  cron
  dhcp
  file_integrity
  file_perms
  firewall
  fs_exports
  fs_layout 
  ftp
  graphical_interface
  ldap
  mail
  nfs
  passwd
  selinux
  services
  smb
  snmp
  ssh
  umask
  )

topics = Array.new
vulns = Array.new
dup_vulns = Array.new
unmatched_vulns = Array.new
all_vulns = Hash.new

# Open the list of stig items and put them into a hash.
stig_file = File.open('open_stig.txt', 'r')
stig_file.each do |line|
  line_items = Array.new
  line_items = line.strip.split()
  if line_items.count > 0
    vid = line_items[0]
    info = line_items[2..line_items.length-1].join(' ')
    all_vulns[vid] = info
  end
end
stig_file.close

puts "There are #{all_vulns.count} vulnerabilities left."

infiles.each do | topic |
  topics.push(topic)
  topic_list = Array.new
  topic_file = File.open(topic).each do |id|
    id = id.strip
    if vulns.include? id
      dup_vulns.push(id)
    else 
      vulns.push(id)
      all_vulns.delete(id)
    end
    topic_list.push(id)
  end
end

puts "###############"
puts "Topics:"
puts topics

if dup_vulns.count > 0
  puts "#######"
  puts "Duplicate Vulnerabilities."
  puts dup_vulns
end

all_vulns.each do |key, value|
  puts "#{key}: #{value}"
end

puts "There are #{all_vulns.count} vulnerabilities left."
